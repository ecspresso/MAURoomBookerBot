package ecspresso.mau;

public enum Buildings {
    NIAGARA("Niagara", "flik=FLIK-0017"),
    G8("Gäddan", "FLIK_0003");

    private final String name;
    private final String flik;

    Buildings(String name, String flik) {
        this.name = name;
        this.flik = flik;
    }

    @Override
    public String toString() {
        return name;
    }

    public String getFlik() {
        return flik;
    }

    public static Buildings convertString(String buildingName) {
        switch(buildingName) {
            // Alla giltiga alternativ.
            case "n" -> {
                return Buildings.NIAGARA;
            }
            case "g8" -> {
                return Buildings.G8;
            }
            default -> {
                return null;
            }
        }
    }
}
