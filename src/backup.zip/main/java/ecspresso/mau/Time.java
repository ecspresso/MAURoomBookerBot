package ecspresso.mau;

import java.time.LocalTime;

public enum Time {
    T0815_1000("08:15"),
    T1015_1300("10:15"),
    T1315_1500("13:15"),
    T1515_1700("15:15"),
    T1715_2000("17:15");

    private final String name;
    private final LocalTime time;
    private boolean booked;

    Time(String name) {
        this.name = name;
        time = LocalTime.parse(name);
    }

    public String getName() {
        return name;
    }

    public LocalTime getTime() {
        return time;
    }

    public boolean isBooked() {
        return booked;
    }

    public void setBooked(boolean booked) {
        this.booked = booked;
    }
}
