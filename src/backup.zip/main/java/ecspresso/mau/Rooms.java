package ecspresso.mau;

public enum Rooms {
    G8249("G8:249", Buildings.G8),
    G8252("G8:252", Buildings.G8),
    G8253("G8:253", Buildings.G8),
    G8255("G8:255", Buildings.G8),
    G8256("G8:256", Buildings.G8),
    G8260("G8:260", Buildings.G8),
    G8262("G8:262", Buildings.G8),
    G8265("G8:265", Buildings.G8),
    NIA0301("NI:A0301", Buildings.NIAGARA),
    NIA0322("NI:A0322", Buildings.NIAGARA),
    NIA0401("NI:A0401", Buildings.NIAGARA),
    NIA0422("NI:A0422", Buildings.NIAGARA),
    NIA0515("NI:A0515", Buildings.NIAGARA),
    NIB0303("NI:B0303", Buildings.NIAGARA),
    NIB0305("NI:B0305", Buildings.NIAGARA),
    NIB0321("NI:B0321", Buildings.NIAGARA),
    NIC0301("NI:C0301", Buildings.NIAGARA),
    NIC0305("NI:C0305", Buildings.NIAGARA),
    NIC0306("NI:C0306", Buildings.NIAGARA),
    NIC0309("NI:C0309", Buildings.NIAGARA),
    NIC0312("NI:C0312", Buildings.NIAGARA),
    NIC0325("NI:C0325", Buildings.NIAGARA),
    NIC0401("NI:C0401", Buildings.NIAGARA);

    private final String name;
    private final Buildings building;

    Rooms(String name, Buildings building) {
        this.name = name;
        this.building = building;
    }
}
