package ecspresso.mau;

public class Room {
    private final String roomName;
    private final Rooms room;
    private final Time T0815_1000 = Time.T0815_1000;
    private final Time T1015_1300 = Time.T1015_1300;
    private final Time T1315_1500 = Time.T1315_1500;
    private final Time T1515_1700 = Time.T1515_1700;
    private final Time T1715_2000 = Time.T1715_2000;

    public Room(String roomName, Rooms room) {
        this.roomName = roomName;
        this.room = room;
    }
}
