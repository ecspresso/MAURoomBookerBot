package ecspresso;

import ecspresso.browser.BrowserHandler;
import ecspresso.browser.RoomKeeper;
import ecspresso.email.Inbox;
import ecspresso.email.Parser;
import ecspresso.kronox.BookKeeper;
import ecspresso.kronox.Queue;
import ecspresso.kronox.UserFilesHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Properties;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class Main {
    public static void main(String[] args) {
        BookKeeper bookKeeper = new BookKeeper();
        RoomKeeper roomKeeper = new RoomKeeper(bookKeeper);

        Queue queue = new Queue();
        UserFilesHandler userFilesHandler = new UserFilesHandler("users/");

        Properties prop = new Properties();
        try (FileInputStream fis = new FileInputStream("email.properties")) {
            prop.load(fis);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        Inbox inbox = new Inbox.Builder()
            .setUsername(prop.getProperty("username"))
            .setPassword(prop.getProperty("password"))
            .setServerIn(prop.getProperty("serverIn"))
            .setPortIn(prop.getProperty("portIn"))
            .setServerOut(prop.getProperty("serverOut"))
            .setPortOut(prop.getProperty("portOut"))
            .build();

        Parser parser = new Parser(inbox, queue, userFilesHandler, bookKeeper);

        roomKeeper.findPrebookedRooms();
        parser.run();
    }


    public void realMain() {
        Logger logger = LoggerFactory.getLogger(Main.class);

        // Schemalagd trådpool?
        logger.debug("Skapar trådpool.");
        ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(2);
        // Innehåller alla bokningar.
        Queue queue = new Queue();
        // Hanterar inläsning av filerna.
        UserFilesHandler userFilesHandler = new UserFilesHandler("users/");

        // Inkorg.
        Properties prop = new Properties();
        logger.debug("Leta efter email.properties.");
        try (FileInputStream fis = new FileInputStream("email.properties")) {
            logger.debug("Läser in email.properties.");
            prop.load(fis);
        } catch (IOException e) {
            logger.error("Kunde inte läsa in mejlinställningar.");
            throw new RuntimeException(e);
        }

        // logger.debug("Skapa inbox.");
        Inbox inbox = new Inbox.Builder()
            .setUsername(prop.getProperty("username"))
            .setPassword(prop.getProperty("password"))
            .setServerIn(prop.getProperty("serverIn"))
            .setPortIn(prop.getProperty("portIn"))
            .setServerOut(prop.getProperty("serverOut"))
            .setPortOut(prop.getProperty("portOut"))
            .build();
        // logger.debug("Inbox skapad.");

        Parser parser = new Parser(inbox, queue, userFilesHandler, new BookKeeper());
        // logger.debug("Parser skapad.");

        // Kolla inkorgen
        // Kör varje 5:e minut, start :02.
        logger.debug("Beräknar alla tider.");
        LocalDateTime now = LocalDateTime.now(ZoneId.of("Europe/Stockholm"));
        logger.debug("Nu är {}", now);
        int minutes = 12 - now.getMinute()%10; // Hur många minuter det är kvar till nästa XX:X2.
        logger.debug("Tid kvar till nästa XX:X2: {}", minutes);
        int parserDelay = (minutes) >= 10 ? (minutes) - 10 : (minutes); // Om minutes >= 10 -> ta bort 10 minuter istället för att vänta.
        logger.debug("Parser fördröjning {}", parserDelay);
        int browserDelay = (  (23 - now.getHour()) * 60   +   60 - now.getMinute()  ) * 60 - now.getSecond() + 5; // timmar, minut och sekund till sekunder kvar till 00:00:05.
        logger.debug("Browser fördröjning {}", browserDelay);

        BrowserHandler browserHandler = new BrowserHandler(queue, parser, "https://schema.mau.se");

        logger.info("Schemalägger parser.");
        scheduler.scheduleAtFixedRate(parser, parserDelay, 10, TimeUnit.MINUTES);

        // Starta 5 minuter innan, varje 24 timmar.
        logger.info("Schemalägger kön.");
        scheduler.scheduleAtFixedRate(browserHandler::emptyQueue, browserDelay - 300, 86400, TimeUnit.SECONDS);

        logger.info("Schemalägger körning av webbläsare.");
        scheduler.scheduleAtFixedRate(browserHandler::runAllBrowsers, browserDelay, 86400, TimeUnit.SECONDS);
    }
}
