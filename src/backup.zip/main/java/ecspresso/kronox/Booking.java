package ecspresso.kronox;

import ecspresso.users.User;

import javax.mail.Address;
import java.util.ArrayList;

public record Booking(User user, z building, ArrayList<Integer> timeslots, Address[] from) {
    public Booking(User user, Building building, ArrayList<Integer> timeslots, Address[] from) {
        this.user = user;
        this.building = building;
        this.from = from;
        this.timeslots = timeslots;
        this.timeslots.sort((x, y) -> x < y ? x : y);
    }

    @Override
    public String toString() {
        return String.format("%s : %s", user.username(), translate());
    }

    public String translate() {
        StringBuilder translated = new StringBuilder();
        for(int t : timeslots) {
            if(translated.length() > 0) {
                translated.append(" & ");
            }

            translated.append(translate(t));
        }

        return translated.toString();
    }

    public static String translate(int t) {
        switch (t) {
            case 1 -> {return "08:15 - 10:00";}
            case 2 -> {return "10:15 - 13:00";}
            case 3 -> {return "13:15 - 15:00";}
            case 4 -> {return "15:15 - 17:00";}
            case 5 -> {return "17:15 - 20:00";}
            default -> {return null;}
        }
    }
}
